package com.resultcopy.rest.model;

import junit.framework.TestCase;

public class PatientTest extends TestCase {

    public void testPatientDetails() {
    }

    public void testAddPatientDetailsItem() {
    }

    public void testGetPatientDetails() {
    }

    public void testSetPatientDetails() {
    }
}